import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { encode as base64Encode } from "https://deno.land/std@0.168.0/encoding/base64.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Voice options - Male and Female options
const VOICE_OPTIONS = {
  male: 'CwhRBWXzGAHq8TQ4Fs17',   // Roger - professional male voice
  female: 'EXAVITQu4vr4xnSDxMaL', // Sarah - professional female voice
};

serve(async (req) => {
  console.log('[elevenlabs-tts] Received request');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { text, voiceId, voiceGender = 'male' } = await req.json();
    
    // Use provided voiceId or select based on gender
    const selectedVoiceId = voiceId || VOICE_OPTIONS[voiceGender as keyof typeof VOICE_OPTIONS] || VOICE_OPTIONS.male;
    
    if (!text) {
      return new Response(JSON.stringify({ error: 'Text is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const ELEVENLABS_API_KEY = Deno.env.get('ELEVENLABS_API_KEY');
    
    if (!ELEVENLABS_API_KEY) {
      console.error('[elevenlabs-tts] ELEVENLABS_API_KEY not configured');
      return new Response(JSON.stringify({ 
        error: 'ElevenLabs API key not configured',
        fallback: true 
      }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('[elevenlabs-tts] Generating speech for text length:', text.length, 'voice:', selectedVoiceId);
    
    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${selectedVoiceId}?output_format=mp3_44100_128`,
      {
        method: 'POST',
        headers: {
          'xi-api-key': ELEVENLABS_API_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text,
          model_id: 'eleven_turbo_v2_5', // Low latency, high quality
          voice_settings: {
            stability: 0.6,
            similarity_boost: 0.75,
            style: 0.3,
            use_speaker_boost: true,
            speed: 1.14, // Adjusted for 162 WPM speech rate (range: 0.7-1.2)
          },
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[elevenlabs-tts] ElevenLabs error:', response.status, errorText);
      return new Response(JSON.stringify({ 
        error: 'Failed to generate speech',
        fallback: true 
      }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const audioBuffer = await response.arrayBuffer();
    const base64Audio = base64Encode(audioBuffer);
    
    console.log('[elevenlabs-tts] Audio generated successfully, size:', audioBuffer.byteLength);

    return new Response(JSON.stringify({ 
      audioContent: base64Audio,
      success: true 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[elevenlabs-tts] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error',
      fallback: true 
    }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { entryId } = await req.json();
    
    if (!entryId) {
      return jsonResponse({ error: 'entryId required' }, 400);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Get the queue entry
    const { data: entry, error: entryError } = await supabase
      .from('match_queue_entries')
      .select('*')
      .eq('id', entryId)
      .single();

    if (entryError || !entry) {
      console.error('Entry not found:', entryError);
      return jsonResponse({ error: 'Entry not found' }, 404);
    }

    if (entry.status !== 'waiting') {
      return jsonResponse({ message: 'Entry not in waiting status' }, 200);
    }

    console.log(`Processing matchmaking for entry ${entryId}, format: ${entry.format}, mode: ${entry.mode}, elo: ${entry.elo}`);

    // Calculate ELO tolerance based on wait time (for ranked matches)
    const waitSeconds = Math.floor((Date.now() - new Date(entry.joined_at).getTime()) / 1000);
    const baseTolerance = 50;
    const toleranceIncrement = Math.floor(waitSeconds / 5) * 50;
    const eloTolerance = Math.min(baseTolerance + toleranceIncrement, 300);

    console.log(`Wait time: ${waitSeconds}s, ELO tolerance: ±${eloTolerance}`);

    // Stale entry cutoff: 15 seconds since last heartbeat
    const staleHeartbeatCutoff = new Date(Date.now() - 15 * 1000).toISOString();

    // Find potential matches - GLOBAL matching (no region filter)
    // Match on: format + mode + status + fresh heartbeat
    let query = supabase
      .from('match_queue_entries')
      .select('*')
      .eq('format', entry.format)
      .eq('mode', entry.mode)
      .eq('status', 'waiting')
      .neq('id', entryId)
      .neq('user_id', entry.user_id)
      .gte('last_heartbeat_at', staleHeartbeatCutoff)
      .order('joined_at', { ascending: true })
      .limit(20);

    // For ranked, apply ELO range filtering
    if (entry.mode === 'ranked') {
      query = query
        .gte('elo', entry.elo - eloTolerance)
        .lte('elo', entry.elo + eloTolerance);
    }

    const { data: candidates, error: candidatesError } = await query;

    if (candidatesError) {
      console.error('Error finding candidates:', candidatesError);
      return jsonResponse({ error: 'Failed to find candidates' }, 500);
    }

    console.log(`Found ${candidates?.length || 0} potential candidates`);

    if (!candidates || candidates.length === 0) {
      return jsonResponse({ message: 'No matches found', matchFound: false }, 200);
    }

    // Filter by opponent type preferences
    const validCandidates = candidates.filter(c => 
      c.opponent_type !== 'ai_only' && entry.opponent_type !== 'ai_only'
    );

    if (validCandidates.length === 0) {
      return jsonResponse({ message: 'No compatible matches', matchFound: false }, 200);
    }

    // For ranked: Check for recent rematches (avoid matching same players within 24h)
    let bestMatch = null;
    
    if (entry.mode === 'ranked') {
      const recentMatchCutoff = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      
      for (const candidate of validCandidates) {
        const { data: recentMatch } = await supabase
          .from('match_history')
          .select('id')
          .or(`and(user_a_id.eq.${entry.user_id},user_b_id.eq.${candidate.user_id}),and(user_a_id.eq.${candidate.user_id},user_b_id.eq.${entry.user_id})`)
          .gte('played_at', recentMatchCutoff)
          .limit(1);

        if (!recentMatch || recentMatch.length === 0) {
          // No recent rematch - try to claim this candidate atomically
          const claimed = await atomicClaimEntry(supabase, candidate.id);
          if (claimed) {
            bestMatch = candidate;
            break;
          }
        }
      }
    } else {
      // Unranked: first-come-first-served, try atomic claims
      for (const candidate of validCandidates) {
        const claimed = await atomicClaimEntry(supabase, candidate.id);
        if (claimed) {
          bestMatch = candidate;
          break;
        }
      }
    }

    if (!bestMatch) {
      console.log('All candidates were already claimed by other matches');
      return jsonResponse({ message: 'No available matches (race condition)', matchFound: false }, 200);
    }

    console.log(`Best match found: ${bestMatch.id}, ELO: ${bestMatch.elo}`);

    // Use topic from entry (or bestMatch if entry has none, or default)
    const debateTopic = entry.topic || bestMatch.topic || 'This House believes that social media does more harm than good';
    
    // Map format to HvH format name
    const hvhFormatMap: Record<string, string> = {
      'LD': 'rapid',
      'AP': 'standard', 
      'WSDC': 'extended',
    };
    const hvhFormat = hvhFormatMap[entry.format] || 'standard';

    // Create the debate room with topic
    const { data: room, error: roomError } = await supabase
      .from('debate_rooms')
      .insert({
        format: entry.format,
        mode: entry.mode,
        region: 'global', // Always global
        status: 'reserved',
        is_ai_opponent: false,
        reserved_until: new Date(Date.now() + 60 * 1000).toISOString(), // 60 seconds to join
        topic: debateTopic,
        hvh_format: hvhFormat,
        current_phase: 'waiting',
      })
      .select()
      .single();

    if (roomError) {
      // Rollback the claim if room creation fails
      await supabase
        .from('match_queue_entries')
        .update({ status: 'waiting' })
        .eq('id', bestMatch.id);
      console.error('Error creating room:', roomError);
      return jsonResponse({ error: 'Failed to create room' }, 500);
    }

    console.log(`Room created: ${room.id}`);

    // Assign roles based on format - RANDOMLY assign sides
    const getRoles = (format: string) => {
      switch (format) {
        case 'LD':
          return { roleA: 'affirmative', roleB: 'negative' };
        case 'BP':
          return { roleA: 'opening_government', roleB: 'opening_opposition' };
        default:
          return { roleA: 'proposition', roleB: 'opposition' };
      }
    };

    const { roleA, roleB } = getRoles(entry.format);
    
    // Randomly decide who gets which side (coin flip)
    const isEntryProposition = Math.random() > 0.5;
    const role1 = isEntryProposition ? roleA : roleB;
    const role2 = isEntryProposition ? roleB : roleA;
    const order1 = isEntryProposition ? 1 : 2; // Proposition speaks first
    const order2 = isEntryProposition ? 2 : 1;

    // Add participants with randomly assigned sides
    const { error: participantsError } = await supabase.from('debate_participants').insert([
      {
        room_id: room.id,
        user_id: entry.user_id,
        is_ai: false,
        role: role1,
        speaking_order: order1,
      },
      {
        room_id: room.id,
        user_id: bestMatch.user_id,
        is_ai: false,
        role: role2,
        speaking_order: order2,
      },
    ]);
    
    console.log(`Assigned ${entry.user_id} as ${role1}, ${bestMatch.user_id} as ${role2}`);

    if (participantsError) {
      console.error('Error creating participants:', participantsError);
      // Cleanup room and rollback
      await supabase.from('debate_rooms').delete().eq('id', room.id);
      await supabase.from('match_queue_entries').update({ status: 'waiting' }).eq('id', bestMatch.id);
      return jsonResponse({ error: 'Failed to create participants' }, 500);
    }

    // Update both queue entries atomically
    const now = new Date().toISOString();
    
    const { error: updateError1 } = await supabase
      .from('match_queue_entries')
      .update({
        status: 'matched',
        matched_at: now,
        matched_with_user_id: bestMatch.user_id,
        room_id: room.id,
      })
      .eq('id', entryId);

    const { error: updateError2 } = await supabase
      .from('match_queue_entries')
      .update({
        status: 'matched',
        matched_at: now,
        matched_with_user_id: entry.user_id,
        room_id: room.id,
      })
      .eq('id', bestMatch.id);

    if (updateError1 || updateError2) {
      console.error('Error updating queue entries:', updateError1, updateError2);
    }

    console.log('Match complete!');

    return jsonResponse({ 
      message: 'Match found!', 
      matchFound: true, 
      roomId: room.id,
      opponent: bestMatch.user_id,
      topic: debateTopic,
      hvhFormat,
    }, 200);

  } catch (error) {
    console.error('Matchmaking error:', error);
    return jsonResponse({ error: 'Internal server error' }, 500);
  }
});

/**
 * Atomically claim a queue entry to prevent race conditions.
 * Updates status from 'waiting' to 'matched' only if it's still waiting.
 * Returns true if claim succeeded, false otherwise.
 */
async function atomicClaimEntry(supabase: any, entryId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('match_queue_entries')
      .update({ status: 'matched' })
      .eq('id', entryId)
      .eq('status', 'waiting') // Only update if still waiting
      .select('id');

    if (error) {
      console.error('Error claiming entry:', error);
      return false;
    }

    // If we got data back, the update succeeded (row was updated)
    return data && data.length > 0;
  } catch (err) {
    console.error('Atomic claim error:', err);
    return false;
  }
}
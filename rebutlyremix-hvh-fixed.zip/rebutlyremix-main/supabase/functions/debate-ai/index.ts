import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface DebateRequest {
  type: 'opponent_response' | 'generate_feedback';
  topic: string;
  userSide: 'proposition' | 'opposition';
  phase: 'opening' | 'rebuttal' | 'closing';
  userArguments: string[];
  aiArguments: string[];
  conversationHistory?: { role: string; content: string }[];
  speechDurationSeconds?: number; // For word count limiting
}

const DEBATE_SYSTEM_PROMPT = `You are an expert competitive debater with extensive knowledge in philosophy, politics, economics, technology, and social sciences. You argue logically, cite real research and studies when relevant, and adapt your arguments to directly counter your opponent's points.

Guidelines:
- Make specific, substantive arguments backed by evidence or logical reasoning
- Reference real studies, statistics, historical examples, or philosophical frameworks
- Directly address and rebut your opponent's specific claims
- Maintain a respectful but assertive debating tone
- Keep responses focused and impactful (2-4 paragraphs max)
- Use structured argumentation: claim, warrant, impact
- Acknowledge strong opponent points while providing counterarguments`;

const FEEDBACK_SYSTEM_PROMPT = `You are an expert debate coach and judge with experience in competitive debate formats (BP, AP, LD, PF, WSDC). Analyze debate performances with specific, actionable feedback based on argumentation quality, evidence use, rebuttal effectiveness, and delivery.

Your feedback must be:
- Specific: Reference exact arguments or phrases from the debate
- Research-backed: Mention debate theory concepts and proven techniques
- Actionable: Provide concrete steps for improvement
- Balanced: Acknowledge strengths before areas for growth
- Structured: Use clear categories with scores and explanations

Scoring rubric (0-100):
- Argumentation (logic, structure, depth of analysis)
- Evidence (use of facts, examples, expert sources)
- Rebuttal (direct engagement with opponent, refutation quality)
- Delivery (clarity, persuasiveness, word economy)
- Strategy (time management, prioritization, narrative)`;

serve(async (req) => {
  console.log('[debate-ai] Received request');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body: DebateRequest = await req.json();
    const { type, topic, userSide, phase, userArguments, aiArguments, conversationHistory, speechDurationSeconds } = body;
    
    console.log('[debate-ai] Request type:', type, 'Phase:', phase);
    
    // Calculate max word count based on speech duration
    // At 1.2x TTS speed, 160 wpm base rate becomes ~192 wpm effective
    // Using 160 wpm to ensure speech fits naturally within allocated time
    // 30s = 80 words, 60s = 160 words, 120s = 320 words
    const WORDS_PER_MINUTE = 160;
    const maxWords = speechDurationSeconds 
      ? Math.floor((speechDurationSeconds / 60) * WORDS_PER_MINUTE)
      : 400; // Default fallback
    
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      console.error('[debate-ai] LOVABLE_API_KEY not configured');
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    let systemPrompt: string;
    let userPrompt: string;
    let tools: any[] | undefined;
    let toolChoice: any | undefined;

    if (type === 'opponent_response') {
      const aiSide = userSide === 'proposition' ? 'opposition' : 'proposition';
      
      systemPrompt = `${DEBATE_SYSTEM_PROMPT}

CRITICAL: Your response must be EXACTLY ${maxWords} words or fewer. Count your words carefully. This is a timed debate speech and you must finish within the allocated time.

You are arguing the ${aiSide} side of this debate.
Motion: "${topic}"

Your opponent (${userSide}) has made the following arguments so far:
${userArguments.length > 0 ? userArguments.map((a, i) => `${i + 1}. ${a}`).join('\n') : 'No arguments yet.'}

Your previous arguments:
${aiArguments.length > 0 ? aiArguments.map((a, i) => `${i + 1}. ${a}`).join('\n') : 'None yet.'}`;

      const phaseInstructions = {
        opening: `Deliver your opening statement. Present 2-3 strong arguments for your side (${aiSide}). Set up the framework for the debate and establish your key themes.`,
        rebuttal: `Deliver your rebuttal. Directly address and refute your opponent's specific arguments. Point out logical flaws, missing evidence, or unconsidered consequences. Then reinforce your own position.`,
        closing: `Deliver your closing statement. Summarize why your side has won the key clashes in this debate. Weigh the impacts and explain why your arguments are more compelling.`
      };

      userPrompt = phaseInstructions[phase];
      
    } else if (type === 'generate_feedback') {
      systemPrompt = FEEDBACK_SYSTEM_PROMPT;
      
      const debateTranscript = conversationHistory?.map(msg => 
        `[${msg.role === 'user' ? 'Debater' : 'AI Opponent'}]: ${msg.content}`
      ).join('\n\n') || '';

      userPrompt = `Analyze this debate performance and provide structured feedback.

Motion: "${topic}"
User's side: ${userSide}

Debate transcript:
${debateTranscript}

User's arguments:
${userArguments.map((a, i) => `${i + 1}. ${a}`).join('\n')}

AI opponent's arguments:
${aiArguments.map((a, i) => `${i + 1}. ${a}`).join('\n')}

Provide detailed, specific feedback using the structured output format.`;

      // Use tool calling for structured feedback
      tools = [{
        type: 'function',
        function: {
          name: 'submit_feedback',
          description: 'Submit structured debate feedback with scores and analysis',
          parameters: {
            type: 'object',
            properties: {
              overallScore: {
                type: 'number',
                description: 'Overall debate performance score 0-100'
              },
              verdict: {
                type: 'string',
                enum: ['win', 'loss', 'close'],
                description: 'Overall debate outcome assessment'
              },
              summary: {
                type: 'string',
                description: 'Brief 2-3 sentence summary of the debate performance'
              },
              categories: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    name: {
                      type: 'string',
                      enum: ['Argumentation', 'Evidence', 'Rebuttal', 'Delivery', 'Strategy']
                    },
                    score: {
                      type: 'number',
                      description: 'Score 0-100 for this category'
                    },
                    feedback: {
                      type: 'string',
                      description: 'Specific, actionable feedback for this category (2-3 sentences)'
                    },
                    strengths: {
                      type: 'array',
                      items: { type: 'string' },
                      description: 'Specific things done well'
                    },
                    improvements: {
                      type: 'array',
                      items: { type: 'string' },
                      description: 'Specific areas to improve with concrete suggestions'
                    }
                  },
                  required: ['name', 'score', 'feedback', 'strengths', 'improvements']
                }
              },
              keyMoments: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    type: {
                      type: 'string',
                      enum: ['strength', 'missed_opportunity', 'effective_rebuttal', 'weak_argument']
                    },
                    description: {
                      type: 'string',
                      description: 'Description of this moment in the debate'
                    },
                    suggestion: {
                      type: 'string',
                      description: 'What could have been done differently (for improvements) or why it was effective (for strengths)'
                    }
                  },
                  required: ['type', 'description', 'suggestion']
                }
              },
              researchSuggestions: {
                type: 'array',
                items: { type: 'string' },
                description: 'Specific topics, studies, or sources to research for future debates on this topic'
              }
            },
            required: ['overallScore', 'verdict', 'summary', 'categories', 'keyMoments', 'researchSuggestions']
          }
        }
      }];
      toolChoice = { type: 'function', function: { name: 'submit_feedback' } };
    } else {
      throw new Error('Invalid request type');
    }

    console.log('[debate-ai] Calling Lovable AI gateway');
    
    const aiRequestBody: any = {
      model: 'google/gemini-3-flash-preview',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      temperature: 0.7,
      max_tokens: 1500
    };

    if (tools) {
      aiRequestBody.tools = tools;
      aiRequestBody.tool_choice = toolChoice;
    }

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(aiRequestBody),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[debate-ai] AI gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: 'Rate limit exceeded. Please try again in a moment.' }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: 'AI service quota exceeded.' }), {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log('[debate-ai] Received response from AI');

    let result: any;

    if (type === 'opponent_response') {
      result = {
        type: 'opponent_response',
        response: data.choices[0]?.message?.content || 'I concede this point.',
        phase
      };
    } else {
      // Extract tool call result for feedback
      const toolCall = data.choices[0]?.message?.tool_calls?.[0];
      if (toolCall && toolCall.function.name === 'submit_feedback') {
        const feedback = JSON.parse(toolCall.function.arguments);
        result = {
          type: 'feedback',
          ...feedback
        };
      } else {
        // Fallback if tool call didn't work
        result = {
          type: 'feedback',
          overallScore: 75,
          verdict: 'close',
          summary: data.choices[0]?.message?.content || 'Good effort in this debate.',
          categories: [],
          keyMoments: [],
          researchSuggestions: []
        };
      }
    }

    console.log('[debate-ai] Returning result');
    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[debate-ai] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

/**
 * debate-timer edge function
 * Authoritative timer for HvH debates.
 *
 * Endpoints (POST body JSON):
 *   { action: "start", roomId, phase, durationSeconds }
 *     => Starts or overrides timer for room. Broadcasts initial time.
 *   { action: "sync", roomId }
 *     => Returns current remaining time to caller and broadcasts sync event.
 *
 * Timer broadcasts are sent on Supabase Realtime channel `room-timer-{roomId}`
 * with event `timer` and payload { phase, remaining, total, serverTs }.
 */

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.47.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface TimerState {
  phase: string;
  startedAt: number; // ms since epoch
  durationMs: number;
}

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
  { auth: { persistSession: false } }
);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { action, roomId, phase, durationSeconds } = body as {
      action: string;
      roomId?: string;
      phase?: string;
      durationSeconds?: number;
    };

    if (!roomId) {
      return new Response(JSON.stringify({ error: "roomId required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`[debate-timer] action=${action} room=${roomId} phase=${phase}`);

    if (action === "start") {
      if (!phase || !durationSeconds) {
        return new Response(
          JSON.stringify({ error: "phase and durationSeconds required for start" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const now = Date.now();

      const timerState: TimerState = {
        phase,
        startedAt: now,
        durationMs: durationSeconds * 1000,
      };

      // Persist to database via RPC
      const { error: updateError } = await supabaseAdmin.rpc("set_timer_state", {
        p_room_id: roomId,
        p_timer_state: timerState,
      });

      if (updateError) {
        console.warn("[debate-timer] Could not persist timer_state:", updateError);
      }

      // Broadcast initial tick
      await broadcastTick(roomId, phase, durationSeconds * 1000, durationSeconds * 1000, now);

      return new Response(JSON.stringify({ ok: true, remaining: durationSeconds }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "sync") {
      // Compute remaining from stored start + duration
      const timerState = await getTimerState(roomId);

      if (!timerState) {
        return new Response(JSON.stringify({ remaining: null, phase: null }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const now = Date.now();
      const elapsed = now - timerState.startedAt;
      const remainingMs = Math.max(0, timerState.durationMs - elapsed);
      const remainingSec = Math.ceil(remainingMs / 1000);

      await broadcastTick(roomId, timerState.phase, remainingMs, timerState.durationMs, now);

      return new Response(
        JSON.stringify({ remaining: remainingSec, phase: timerState.phase }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(JSON.stringify({ error: "unknown action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[debate-timer] Error:", err);
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

async function getTimerState(roomId: string): Promise<TimerState | null> {
  const { data, error } = await supabaseAdmin.rpc("get_timer_state", {
    p_room_id: roomId,
  });

  if (error || !data) {
    console.warn("[debate-timer] Could not load timer_state:", error);
    return null;
  }

  return data as TimerState;
}

async function broadcastTick(
  roomId: string,
  phase: string,
  remainingMs: number,
  totalMs: number,
  serverTs: number
) {
  const channelName = `room-timer-${roomId}`;
  const channel = supabaseAdmin.channel(channelName);

  await channel.send({
    type: "broadcast",
    event: "timer",
    payload: {
      phase,
      remaining: Math.ceil(remainingMs / 1000),
      total: Math.ceil(totalMs / 1000),
      serverTs,
    },
  });

  // Immediately remove channel to avoid resource leak in stateless function
  await supabaseAdmin.removeChannel(channel);
}
